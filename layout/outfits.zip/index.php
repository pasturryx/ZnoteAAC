<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Tibia Outfit Images Generator 0.1.2</title>
</head>
<body>
	<span style="font-size:20px">
        This is index file.<br/>
        Open <b>animoutfit.php</b> with valid parameters to generate animated outfit image. For example:<br/>
        <a href="animoutfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2">
            animoutfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2
        </a><br/>
        <br/>
        Open <b>outfit.php</b> with valid parameters to generate static outfit image. For example:<br/>
        <a href="outfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2">
            outfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2
        </a><br/>
    </span>
</body>
</head>
</html>
